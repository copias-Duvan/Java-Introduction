/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instancias;

/**
 *
 * @author Daniel
 */
public class ClasePrincipal {
    
    public static void main(String[] args) {
        // Herencia ==> jerarquia
        // Herencia ==> es-un
        /*
            Automovil es-un Vehiculo
            Automovil es-un Coche
            Autobus es-un Vehiculo
        */
        Automovil automovil = new Automovil();
        Autobus autobus = new Autobus();
        Vehiculo vehiculo = new Vehiculo();
        Helicoptero helicop = new Helicoptero();
        
        System.out.println(automovil instanceof Automovil);
        System.out.println(automovil instanceof Vehiculo);
        System.out.println(automovil instanceof Coche);
        
        Vehiculo[] vehiculos = new Vehiculo[4];
        vehiculos[0] = automovil;
        vehiculos[1] = autobus;
        vehiculos[2] = vehiculo;
        
        for(int i = 0; i < vehiculos.length; i++) {
            System.out.println("posicion " + i);
            if (vehiculos[i] instanceof Vehiculo) {
                vehiculos[i].acelerar();
            } 
            if (vehiculos[i] instanceof Automovil) {
                ((Automovil) vehiculos[i]).abrirVentanas();
            } 
            if (vehiculos[i] instanceof Autobus) {
                ((Autobus) vehiculos[i]).recogerPasajero();
            }
            if(vehiculos[i] instanceof Coche) {
                ((Coche) vehiculos[i]).frenar();
            }
        }
    }
}
