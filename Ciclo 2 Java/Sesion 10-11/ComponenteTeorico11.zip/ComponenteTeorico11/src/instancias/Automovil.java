/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instancias;

/**
 *
 * @author Daniel
 */
public class Automovil extends Vehiculo implements Coche {
    
    public void abrirVentanas() {
        System.out.println("Abriendo ventanas");
    }
    
    @Override
    public void frenar() {
        System.out.println("Frenando");
    }
}
