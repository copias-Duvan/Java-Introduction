/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instancias;

/**
 *
 * @author Daniel
 */
public class Autobus extends Vehiculo {
    
    public void recogerPasajero() {
        System.out.println("Recogiendo pasajero");
    }
}
