/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componenteteorico11;

import interfaces.InterfazAnimal;
import interfaces.SerVivo;

/**
 *
 * @author Daniel
 */

// Herencia
// extends ==> palabra reservada con la cual se indica que una clase hereda de otra clase
//      public class Perro extends Animal
// implements ==> palabra reservada con la cual se indica que una clase implementa una o varias interfaces
//      public class Perro implements Interfaz1, Interfaz2, ..., etc

// Herencia
// Java solamente permite herencia simple (una clase solamente puede heredar de una clase y no de varias)
// Con interfaces, Java si permite que una clase implemente multiples interfaces
// Incluso una clase en Java puede implementar una interfaz además de heredar de otra clase
public class Perro implements InterfazAnimal, SerVivo {

    @Override
    public void hacerSonido(String sonido) {
        System.out.println("El perro hace el sonido: " + sonido);
    }

    @Override
    public void caminar(int pasos) {
        System.out.println("El perro dio " + pasos  + " pasos");
    }

    @Override
    public void respirar() {
        System.out.println("El perro respiró");
    }
    
    @Override
    public String asignarFamilia(String familia) {
        return "Animal";
    }
    
}
