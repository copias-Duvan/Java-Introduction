/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package componenteteorico11;

/**
 *
 * @author Daniel
 */
public class ComponenteTeorico11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // No se puede crear una instancia de una clase abstracta o una interfaz
        // interfaces.Animal animalInterfaz = new interfaces.Animal();
        // clasesabstractas.Animal animalCA = new clasesabstractas.Animal();
        
        Perro perro = new Perro();
        perro.notify();
        
        Helicoptero hel = new Helicoptero();
        hel.notify();
    }
    
}
