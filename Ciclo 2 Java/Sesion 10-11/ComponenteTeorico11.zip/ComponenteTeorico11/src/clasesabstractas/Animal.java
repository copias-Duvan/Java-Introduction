/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesabstractas;

/**
 *
 * @author Daniel
 */
public abstract class Animal {
    
    // Atributos
    public int cantidadPatas;
    private String identificador;
    protected boolean despierto;
    protected int peso;
    public static String TIPO = "Mamifero";
    public final String categoria = "Animal";
    
    // Constructor(es)
    public Animal(int cantidadPatas) {
        this.cantidadPatas = cantidadPatas;
    }
    // No se puede crear una instancia de una clase abstracta
    // Pero una clase hija dentro de su constructor puede invocar el constructor de una clase abstracta
    
    // Métodos
    // Abstractos
    public abstract void hacerSonido(String sonido);
    protected abstract void caminar(int pasos);
    
    // Concretos
    public void comer(int kilos) {
        this.peso += kilos;
    }
}
