/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * @author Daniel
 */

// La palabra reservada interface nos permite definir interfaces en Java
// Java no permite crear instancias de una interfaz
// InterfazAnimal animal = new InterfazAnimal() ==> no está permitido.
public interface InterfazAnimal extends Familia {
    
    // Atributos
    /*
    Dentro de una interfaz
    Si no se especifica el modificador de acceso, automaticamente ==> public
    Solamente se pueden crear atributos publicos.
    Todo atributo que se defina es automaticamente estático (no se requiere instancia)
    Todo atributo que se defina es automaticamente final (su valor no cambia)
    */
    int peso = 0; // ==> public static final int peso = 0;
    int cantidadPatas = 4;
    int estatura = 100;
    
    // Constructores
    // No hay
    
    // Métodos
    // Solamente se pueden definir métodos abstractos
    // Si no se coloca la palabra abstract, java la asume automáticamente
    // Todo método de una interfaz tiene modificador de acceso público.
    public abstract void hacerSonido(String sonido);
    void caminar(int pasos); // public abstract caminar(int pasos);
    
    // 1. modificador acceso
    // 2. tipo de dato
    // 3. nombre del método
    // 4. parámetros
}
