/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componenteteorico10;

/**
 *
 * @author Daniel
 */
public class Perro extends Animal {
    
    public void hacerSonido(String sonido) {
        System.out.println("El perro hace el sonido: " + sonido);
    }
}
