/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componenteteorico10;

/**
 *
 * @author Daniel
 */
public class Gato extends Animal {
    
    @Override
    // Componentes de un método
    /*
    1. Modificador de acceso: public, private, protected
    2. tipo de dato: int, String, boolean,void, ...
    3. Nombre del método
    4. Parámetros
    5. Implementación del método (contenido dentro de {})
    */
    public void hacerSonido(String sonido) {
        System.out.println("El gato hace el sonido: " + sonido);
    }
}
