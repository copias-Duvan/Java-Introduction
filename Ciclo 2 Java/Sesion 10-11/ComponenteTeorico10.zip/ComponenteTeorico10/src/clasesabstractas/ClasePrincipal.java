/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesabstractas;

/**
 *
 * @author Daniel
 */
public class ClasePrincipal {
    
    public static void main(String args[]) {
        // Animal animal = new Animal(); ==> no se puede crear una instancia de una clase abstracta.
        Perro perro = new Perro();
        Gato gato = new Gato();
        perro.hacerSonido("guau");
        gato.hacerSonido("miau");
        perro.caminar(2);
        gato.caminar(5);
    }
}
