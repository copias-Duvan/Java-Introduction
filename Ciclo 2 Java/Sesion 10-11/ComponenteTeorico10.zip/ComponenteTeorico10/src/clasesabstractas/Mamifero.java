/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesabstractas;

/**
 *
 * @author Daniel
 */
public abstract class Mamifero extends Animal {
    
    public int peso;
    
    public abstract void comer(int kgs);
}
