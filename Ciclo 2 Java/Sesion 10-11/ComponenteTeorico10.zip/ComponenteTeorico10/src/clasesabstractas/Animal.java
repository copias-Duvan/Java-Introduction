/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesabstractas;

/**
 *
 * @author Daniel
 */

// CLASES ABSTRACTAS
/*
Son clases que me permiten agregar definiciones de métodos sin implementar
- Las clases hijas están obligadas a implementar los métodos de la clase abstracta
- Esa obligación mencionada arriba, solamente aplica si la clase no es abstracta
- Si la clase hija es abstracta, no está obligada a implementar los métodos de la clase padre
- Una clase nieta si debe implementar todos los métodos tanto de las clases hija, como padre, si no es abstracta
*/

// DEFINIR UNA CLASE COMO ABSTRACTA
// Indicar con la palabra reservada abstract en la definición de la clase
public abstract class Animal {
    
    
    // Definir un método que no va a tener implementación
    // 1. Modificador de Acceso: SI
    // 1a. Abstracto ==> abstract
    // 2. Tipo de dato: SI
    // 3. Nombre del método: SI
    // 4. Parámetros: SI
    // 5. Implementación: NO
    // 6. Finalizar la línea con ;
    public abstract void hacerSonido(String sonido);
    
    // Definir un método como abstracto
    // Garantiza que todas las clases, sin excepción, que hereden de esta superclase
    // Deben implementar obligatoriamente un método con las caracteristicas descritas
    // En la definición del mismo.
    
    public void caminar(int pasos) {
        System.out.println("El animal dio " + pasos + " pasos.");
    }
}
