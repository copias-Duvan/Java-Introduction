/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package componentepractico10;

/**
 *
 * @author Daniel
 */
public interface Vista {
    
    public abstract String metodo1();
    public abstract String metodo2();
    public abstract String metodo3();
}
