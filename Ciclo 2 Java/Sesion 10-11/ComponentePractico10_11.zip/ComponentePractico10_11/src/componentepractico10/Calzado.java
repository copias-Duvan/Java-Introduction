/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componentepractico10;

/**
 *
 * @author Daniel
 */
public class Calzado extends Producto implements Vista {
    
    private int talla;

    public Calzado(int talla, String codigo, String descripcion, int precioCompra, int precioVenta, int cantidadBodega, int cantidadMinima, int cantidadMaxima) {
        super(codigo, descripcion, precioCompra, precioVenta, cantidadBodega, cantidadMinima, cantidadMaxima);
        this.talla = talla;
    }

    public int getTalla() {
        return talla;
    }

    public void setTalla(int talla) {
        this.talla = talla;
    }
    
    @Override
    public boolean solicitarPedido() {
        return this.getCantidadBodega() < this.getCantidadMinima();
    }
    
    @Override
    public double calcularTotalPagar(int unidades) {
        return unidades * this.getPrecioCompra();
    }
    
    @Override
    public String mostrar() {
        String cadena = "%1$s-%2$s-%3$d-%4$d-%5$d-%6$d-%7$d-%8$d";
        // posicion %n, donde n es la posicion del parametro en el metodo format.
        // formato $x, donde x va a ser el formato, s ==> cadena, d ==> digitos
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion(), this.getPrecioCompra(), this.getPrecioVenta(), this.getCantidadBodega(), this.getCantidadMinima(), this.getCantidadMaxima(), this.talla);
        //System.out.println(info);
        return infoFormateada;
    }
    
    @Override
    public String metodo1() {
        String cadena = "%1$s-%2$s-%3$d-%4$d-%5$d-%6$d-%7$d-%8$d";
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion(), this.getPrecioCompra(), this.getPrecioVenta(), this.getCantidadBodega(), this.getCantidadMinima(), this.getCantidadMaxima(), this.talla);
        return infoFormateada;
    }
    
    @Override
    public String metodo2() {
        String cadena = "%1$s-%2$s";
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion());
        return infoFormateada;
    }
    
    @Override
    public String metodo3() {
        String cadena = "%1$s-%2$s-%3$d-%4$d";
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion(), this.getPrecioCompra(), this.getPrecioVenta());
        return infoFormateada;
    }
}
