/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componentepractico10;

/**
 *
 * @author Daniel
 */
public class Prenda extends Producto implements Vista {
    
    // Atributos
    private String talla;
    private boolean permitePlanchado;
    
    // Constructor
    public Prenda(String talla, boolean permitePlanchado, String codigo, String descripcion, int precioCompra, int precioVenta, int cantidadBodega, int cantidadMinima, int cantidadMaxima) {
        super(codigo, descripcion, precioCompra, precioVenta, cantidadBodega, cantidadMinima, cantidadMaxima);
        this.talla = talla;
        this.permitePlanchado = permitePlanchado;
    }
    
    // Métodos

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public boolean isPermitePlanchado() {
        return permitePlanchado;
    }

    public void setPermitePlanchado(boolean permitePlanchado) {
        this.permitePlanchado = permitePlanchado;
    }

    @Override
    public boolean solicitarPedido() {
        return this.getCantidadBodega() < this.getCantidadMinima();
    }
    
    @Override
    public double calcularTotalPagar(int unidades) {
        return unidades * this.getPrecioCompra();
    }
    
    @Override
    public String mostrar() {
        String cadena = "%1$s-%2$s-%3$d-%4$d-%5$d-%6$d-%7$d-%8$s-%9$s";
        // posicion %n, donde n es la posicion del parametro en el metodo format.
        // formato $x, donde x va a ser el formato, s ==> cadena, d ==> digitos
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion(), this.getPrecioCompra(), this.getPrecioVenta(), this.getCantidadBodega(), this.getCantidadMinima(), this.getCantidadMaxima(), this.talla, this.permitePlanchado);
        //System.out.println(info);
        return infoFormateada;
    }
    
    @Override
    public String metodo1() {
        String cadena = "%1$s-%2$s-%3$d-%4$d-%5$d-%6$d-%7$d-%8$s-%9$s";
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion(), this.getPrecioCompra(), this.getPrecioVenta(), this.getCantidadBodega(), this.getCantidadMinima(), this.getCantidadMaxima(), this.talla, this.permitePlanchado);
        return infoFormateada;
    }
    
    @Override
    public String metodo2() {
        String cadena = "%1$s-%2$s";
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion());
        return infoFormateada;
    }
    
    @Override
    public String metodo3() {
        String cadena = "%1$s-%2$s-%3$d-%4$d";
        String infoFormateada = String.format(cadena, this.getCodigo(), this.getDescripcion(), this.getPrecioCompra(), this.getPrecioVenta());
        return infoFormateada;
    }
    
}
